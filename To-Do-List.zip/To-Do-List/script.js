document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('todo-form');
    const taskInput = document.getElementById('task');
    const taskList = document.getElementById('task-list');
  
    // Load tasks from local storage
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  
    // Display tasks
    function displayTasks() {
      taskList.innerHTML = '';
      tasks.forEach(function(task, index) {
        const li = document.createElement('li');
        li.innerHTML = `
          <span>${task}</span>
          <button class="delete" data-index="${index}">Delete</button>
        `;
        taskList.appendChild(li);
      });
    }
  
    displayTasks();
  
    // Add new task
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const taskValue = taskInput.value.trim();
      if (taskValue !== '') {
        tasks.push(taskValue);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        displayTasks();
        taskInput.value = '';
      }
    });
  
    // Delete task
    taskList.addEventListener('click', function(e) {
      if (e.target.classList.contains('delete')) {
        const index = e.target.getAttribute('data-index');
        tasks.splice(index, 1);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        displayTasks();
      }
    });
  });
  